package com.example.andrew.profile_ui_1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import java.lang.String;

public class ProfileActivity extends AppCompatActivity {

    String name = ""; //user's name
    String major = ""; //user's major
    String email = ""; //user's email

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        Button nameButton; //profile ui name edit button
        Button majorButton; //profile ui major edit button
        Button emailButton; //profile ui email edit button

        nameButton = (Button) findViewById(R.id.nameEdit);
        majorButton = (Button) findViewById(R.id.majorEdit);
        emailButton = (Button) findViewById(R.id.emailEdit);

        nameButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                System.out.println("Enter your name: "); //temporary until I figure out what is going in here, this is just for testing the buttons
            }
        });

        majorButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                System.out.println("Enter your major: ");
            }
        });

        emailButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                System.out.println("Enter your email: ");
            }
        });
    }
}
